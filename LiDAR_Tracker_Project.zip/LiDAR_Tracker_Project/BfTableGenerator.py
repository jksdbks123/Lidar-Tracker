from tqdm import tqdm
import matplotlib.pyplot as plt
import dpkt
import numpy as np
import open3d as op3 
import pandas as pd
import os

class RansacCollector():
    def __init__(self,pcap_path,output_file_path,update_frame_num,thred_map_path = None): 
        """
        update_frame_num -> frame indexes to use in the development of td map
        aggregated_map -> 1800 * 32 * ts
        thred_map -> thredshold map
        
        """
        self.update_frame_num = update_frame_num
        self.pcap_path = pcap_path
        self.aggregated_map = None
        self.thred_map = thred_map_path
        self.theta = np.sort(np.array([[-25,1.4],[-1,-4.2],[-1.667,1.4],[-15.639,-1.4],
                            [-11.31,1.4],[0,-1.4],[-0.667,4.2],[-8.843,-1.4],
                            [-7.254,1.4],[0.333,-4.2],[-0.333,1.4],[-6.148,-1.4],
                            [-5.333,4.2],[1.333,-1.4],[0.667,4.2],[-4,-1.4],
                            [-4.667,1.4],[1.667,-4.2],[1,1.4],[-3.667,-4.2],
                            [-3.333,4.2],[3.333,-1.4],[2.333,1.4],[-2.667,-1.4],
                            [-3,1.4],[7,-1.4],[4.667,1.4],[-2.333,-4.2],
                            [-2,4.2],[15,-1.4],[10.333,1.4],[-1.333,-1.4]
                            ])[:,0])
        self.azimuths = np.arange(0,360,0.2)
        
        if 'OutputFile' not in os.listdir(output_file_path):
            os.mkdir(os.path.join(output_file_path,'OutputFile'))
        self.output_path = os.path.join(output_file_path,'OutputFile')
        
        
    def gen_tdmap(self):
    
        lidar_reader = TDmapLoader(self.pcap_path)
        frame_gen = lidar_reader.frame_gen()
        td_maps = [] 
        print('Loading pcap...')
        for i in tqdm(range(self.update_frame_num)):
            one_frame = next(frame_gen)
            if one_frame is None:
                break 
            td_maps.append(one_frame)
        aggregated_maps = np.array(td_maps) # 1800 * 32 * len(ts)
        self.aggregated_map = aggregated_maps

    def gen_thredmap(self,d,thred_s,N,delta_thred,step):
        
        if self.aggregated_map is None:
            return None
        aggregated_maps_temp = self.aggregated_map.copy()
        threshold_map = np.zeros((32,1800))
        
        print('Generating Threshold Map')
        for i in range(32):
            for j in range(1800):
                t_s = aggregated_maps_temp[:,i,j].copy()
                threshold_value = self.get_thred(t_s,d,thred_s,N,delta_thred,step)
                threshold_map[i,j] = threshold_value
        self.thred_map = threshold_map

    def get_thred_modified(self,ts,d ,thred_s ,N ,delta_thred ,step):# Ransac Para
        ts_temp = ts.copy()
        ts_temp[ts_temp == 0] = 1000
        valid_dises = []
        for i in range(N):
            sample = np.random.choice(ts_temp,replace=False)
            if len(ts_temp[(ts_temp > sample - d)&(ts_temp < sample + d)])/len(ts_temp) > thred_s:
                valid_dises.append(sample)
        if len(valid_dises) == 0:
            return 1000
            
        cur_thred = np.min(valid_dises)
        
        while True:
            next_thred = cur_thred - step
            if (len(ts[ts > next_thred])/len(ts) - len(ts[ts > cur_thred])/len(ts)) < delta_thred:
                break
            cur_thred = next_thred
            
        return next_thred
    def get_thred(self,ts,d ,thred_s ,N ,delta_thred ,step ):# Ransac Para
        
        emp_ratio = len(ts[ts==0])/len(ts)
        if emp_ratio > 0.8:
            return 1000
        ts = ts[ts!=0]
        flag = True                             
        for i in range(N):
            sample = np.random.choice(ts,replace=False)
            if len(ts[(ts > sample - d)&(ts < sample + d)])/len(ts) > thred_s:
                flag = False
                break
        if flag:
            return 1000
        cur_thred = sample
        while True:
            next_thred = cur_thred - step
            if (len(ts[ts > next_thred])/len(ts) - len(ts[ts > cur_thred])/len(ts)) < delta_thred:
                break
            cur_thred = next_thred
        return next_thred
    
    def gen_pcdseq(self,frame_index_list): # gen_pcdseq is to generate pcd sequence, background points are represented by red and the targets are labeled by blue
        
        pcds_dir = os.path.join(self.output_path,'PcdSequence')
        if 'PcdSequence' not in os.listdir(self.output_path):
            os.mkdir(pcds_dir)
        print('Saving Pcd Sequence')
        for i in tqdm(frame_index_list):
            pcd = self.gen_pcd(i)
            op3.io.write_point_cloud(pcds_dir+"/{}.pcd".format(i), pcd)
        
                
    def save_tdmap(self):
        np.save(os.path.join(self.output_path,'thred_map.npy'),self.thred_map)
        print('Thred Map Saved at',os.path.join(self.output_path ))
    
    def gen_pcd(self,frame_index):
        rbg_red = np.array([204,47,107]) # red
        rbg_blue = np.array([0,0,255]) # blue
        td_freq_map = self.td_maps[frame_index]
        Xs = []
        Ys = []
        Zs = []
        for i in range(td_freq_map.shape[0]):
            longitudes = self.theta[i] * np.pi / 180
            latitudes = self.azimuths * np.pi / 180 
            hypotenuses = td_freq_map[i] * np.cos(longitudes)
            X = hypotenuses * np.sin(latitudes)
            Y = hypotenuses * np.cos(latitudes)
            Z = td_freq_map[i] * np.sin(longitudes)
            Label =  (td_freq_map[i]<self.thred_map[i])
            Valid_ind =  (td_freq_map[i] != 0)&(Label) # None zero index
            Xs.append(X[Valid_ind])
            Ys.append(Y[Valid_ind])
            Zs.append(Z[Valid_ind])
        Xs = np.concatenate(Xs)
        Ys = np.concatenate(Ys)
        Zs = np.concatenate(Zs)
        # Labels = np.concatenate(Labels)
        color_labels = np.full((len(Xs),3),rbg_blue)
        # color_labels[Labels == 1] = rbg_blue
        # color_labels[Labels == 0] = rbg_red
        
        pcd = op3.geometry.PointCloud()
        pcd.points = op3.utility.Vector3dVector(np.concatenate([Xs.reshape(-1,1),Ys.reshape(-1,1),Zs.reshape(-1,1)],axis = 1))
        pcd.colors = op3.utility.Vector3dVector(color_labels/255)
        
        return pcd
    
        

class TDmapLoader():
    def __init__(self,file_path): 
        self.Data_order = np.array([[-25,1.4],[-1,-4.2],[-1.667,1.4],[-15.639,-1.4],
                                    [-11.31,1.4],[0,-1.4],[-0.667,4.2],[-8.843,-1.4],
                                    [-7.254,1.4],[0.333,-4.2],[-0.333,1.4],[-6.148,-1.4],
                                    [-5.333,4.2],[1.333,-1.4],[0.667,4.2],[-4,-1.4],
                                    [-4.667,1.4],[1.667,-4.2],[1,1.4],[-3.667,-4.2],
                                    [-3.333,4.2],[3.333,-1.4],[2.333,1.4],[-2.667,-1.4],
                                    [-3,1.4],[7,-1.4],[4.667,1.4],[-2.333,-4.2],
                                    [-2,4.2],[15,-1.4],[10.333,1.4],[-1.333,-1.4]
                                    ])
        self.laser_id = np.full((32,12),np.arange(32).reshape(-1,1).astype('int'))
        self.timing_offset = self.calc_timing_offsets()
        self.omega = self.Data_order[:,0]
        self.lidar_reader = 0
        self.file_path = file_path
        self.load_reader()
        
    def load_reader(self):
        try:
            fpcap = open(self.file_path, 'rb')
            self.lidar_reader = dpkt.pcap.Reader(fpcap)
        except Exception as ex:
            print(str(ex))

    def read_uint32(self,data, idx):
        return data[idx] + data[idx+1]*256 + data[idx+2]*256*256 + data[idx+3]*256*256*256
    def read_firing_data(self,data):
        block_id = data[0] + data[1]*256
        azimuth = (data[2] + data[3] * 256) / 100 # degree
        firings = data[4:].reshape(32, 3) 
        distances = firings[:, 0] + firings[:, 1] * 256 # mm 
        intensities = firings[:, 2] # 0-255
        return distances, intensities, azimuth #(1,0)
        
    def calc_timing_offsets(self):
        timing_offsets = np.zeros((32,12))  # Init matrix
        # constants
        full_firing_cycle = 55.296  # μs
        single_firing = 2.304  # μs
        # compute timing offsets
        for x in range(12):
            for y in range(32):
                dataBlockIndex = (x * 2) + int((y / 16))
                dataPointIndex = y % 16
                timing_offsets[y][x] = (full_firing_cycle * dataBlockIndex) +(single_firing * dataPointIndex)
        return np.array(timing_offsets).T

    def calc_precise_azimuth(self,azimuth_per_block):

        # block_number: how many blocks are required to be processed 

        org_azi = azimuth_per_block.copy()
        precision_azimuth = []
        # iterate through each block
        for n in range(len(org_azi)): # n=0..11
            azimuth = org_azi.copy()
            try:
                # First, adjust for an Azimuth rollover from 359.99° to 0°
                if azimuth[n + 1] < azimuth[n]:
                    azimuth[n + 1] += 360

                # Determine the azimuth Gap between data blocks
                azimuth_gap = azimuth[n + 1] - azimuth[n]
            except:
                if azimuth[n] < azimuth[n-1]:
                    azimuth[n] += 360
                azimuth_gap = azimuth[n] - azimuth[n-1]

            factor = azimuth_gap / 32.
            k = np.arange(32)
            precise_azimuth = azimuth[n] + factor * k
            precision_azimuth.append(precise_azimuth)

        precision_azimuth = np.array(precision_azimuth).T
        return precision_azimuth # 32 * 12

    def calc_cart_coord(self,distances, azimuth):# distance: 12*32 azimuth: 12*32
        # convert deg to rad
        longitudes = self.omega * np.pi / 180.
        latitudes = azimuth * np.pi / 180.

        hypotenuses = distances * np.cos(longitudes)

        X = hypotenuses * np.sin(latitudes)
        Y = hypotenuses * np.cos(latitudes)
        Z = distances * np.sin(longitudes)
        return X, Y, Z
    

    def parse_one_packet(self,data):
        data = np.frombuffer(data, dtype=np.uint8).astype(np.uint32)
        blocks = data[0:1200].reshape(12, 100)
        # Timestamp = self.read_uint32(data[1200:1204],0)
        distances = []#12*32
        intensities = []#12*32
        azimuth_per_block = [] #(12,0)
        # iteratie through each block
        for i, blk in enumerate(blocks):
            dists, intens, angles = self.read_firing_data(blk)
            distances.append(dists) #12*32
            intensities.append(intens) #12*32
            azimuth_per_block.append(angles)

        azimuth_per_block = np.array(azimuth_per_block).T
        distances = 4/1000*np.array(distances).T # 32,12
        intensities = np.array(intensities).T # 32,12

        return distances,intensities, azimuth_per_block # 12*0
 
    

    def cal_angle_diff(self,advance_angle,lagging_angle):
        if advance_angle < lagging_angle:
            return advance_angle + 360 - lagging_angle
        else:
            return advance_angle - lagging_angle
    
    def frame_gen(self):
        frame_initial_azimuth = -1
        cur_azimuth = -1
        culmulative_azimuth = 0
        culmulative_azimuth_values = []
        culmulative_laser_ids = []
        culmulative_distances = []
        while True:
            Td_map = np.zeros((32,1800))
            Intens_map = np.zeros((32,1800))
            while True:
                try:
                    ts,buf = next(self.lidar_reader)
                except (StopIteration,dpkt.NeedData) as e1:
                    yield None
                if len(buf) == 1248:
                    eth = dpkt.ethernet.Ethernet(buf)
                    data = eth.data.data.data
                    packet_status = eth.data.data.sport
                    if packet_status == 2368:
                        if len(data)<1206:
                            culmulative_azimuth += 2.4
                            continue
                        # 32,12, 32,12, （12，） azi
                        distances,intensities,azimuth_per_block = self.parse_one_packet(data)
                        azimuth = self.calc_precise_azimuth(azimuth_per_block) # 32 x 12
                        
                        
                        if frame_initial_azimuth == -1: #initialization
                            frame_initial_azimuth = azimuth_per_block[0]
                            cur_azimuth = azimuth_per_block[-1]
                            culmulative_azimuth_values.append(azimuth)
                            culmulative_laser_ids.append(self.laser_id)
                            culmulative_distances.append(distances)
                            # azimuth_ind = azimuth_ind.flatten()
                            # Td_map[self.laser_id,azimuth_ind] = distances.flatten()
                            culmulative_azimuth += self.cal_angle_diff(azimuth_per_block[-1],azimuth_per_block[0])
                        else:# non-initialization
                            diff = self.cal_angle_diff(azimuth_per_block[-1],cur_azimuth)
                            culmulative_azimuth += diff 
                            
                            if culmulative_azimuth > 360: 
                                
                                
                                culmulative_azimuth_values.append(azimuth)
                                culmulative_laser_ids.append(self.laser_id)
                                culmulative_distances.append(distances)
                                
                                culmulative_azimuth_values = np.concatenate(culmulative_azimuth_values,axis = 1)
                                culmulative_azimuth_values += self.Data_order[:,1].reshape(-1,1)
                                culmulative_laser_ids = np.concatenate(culmulative_laser_ids,axis = 1).flatten()
                                culmulative_distances = np.concatenate(culmulative_distances,axis = 1).flatten()
                                
                                culmulative_azimuth_inds = np.around(culmulative_azimuth_values/0.2).astype('int').flatten()
                                culmulative_azimuth_inds[culmulative_azimuth_inds > 1799] -= 1800
                                culmulative_azimuth_inds[culmulative_azimuth_inds < 0 ] += 1800
                                
                                Td_map[culmulative_laser_ids,culmulative_azimuth_inds] = culmulative_distances
                                culmulative_azimuth = 0
                                culmulative_azimuth_values = []
                                culmulative_laser_ids = []
                                culmulative_distances = []
                                
                                cur_azimuth = azimuth_per_block[-1]
                                
                                
                                yield Td_map[np.argsort(self.omega),:] #32*1800
                                
                            else:
                                culmulative_azimuth_values.append(azimuth)
                                culmulative_laser_ids.append(self.laser_id)
                                culmulative_distances.append(distances)
                                cur_azimuth = azimuth_per_block[-1]
            
if __name__ == "__main__":
    os.chdir(r'/Users/czhui960/Documents/Lidar/RawLidarData/USAPKWY')
    # thred_map = np.load(r'Output File/thred_map_1200.npy')
    collector = RansacCollector(pcap_path=r'./USApkwy.pcap',update_frame_num=2000)
    collector.gen_tdmap()
    # collector.gen_thredmap(d = 1.4,thred_s = 0.7,N = 20,delta_thred = 1e-3,step = 0.01)
    # collector.gen_pcdseq(np.arange(0,5000))
    # """
    
    # Run This Code, An Analysis Result Will Be Saved in The Output Folder.
    
    # """
    # os.chdir(r'/Users/czhui960/Documents/Lidar/RawLidarData/LiDAR Data For Zhihui/LosAltosInt')
    # frame_set = np.arange(0,17950,1).astype('int')
    # Ns = [100,200,300,400,500,600,900,1000,1200,1500,1800,2000,3000,3600]
    # collector = RansacCollector(pcap_path=r'./2020-12-19-16-30-0.pcap',frames_set = frame_set)
    # collector.gen_tdmap()
    # collector.sampling_effectiveness_test(Ns)
    
    